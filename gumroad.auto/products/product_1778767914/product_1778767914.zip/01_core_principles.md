# 10 Core UI/UX Principles

## 1. Clarity Over Cleverness
Users shouldn't have to think. Every interaction should be obvious.

## 2. Visual Hierarchy
Guide the eye with size, weight, and contrast. Most important = biggest.

## 3. Consistency
Same action = same result. Same look = same function.

## 4. Feedback
Every action needs a reaction. Loading states, success messages, error alerts.

## 5. Accessibility
Minimum 4.5:1 contrast ratio. Tab navigation. Alt text on images.

## 6. Mobile-First
Design for the smallest screen first, then expand.

## 7. Progressive Disclosure
Show only what's needed. Reveal complexity on demand.

## 8. Error Prevention
Confirm destructive actions. Validate in real-time. Undo when possible.

## 9. Fitts's Law
Bigger click targets = easier to hit. Keep related actions close together.

## 10. The 3-Click Rule
Key actions should be reachable in 3 clicks or fewer.
