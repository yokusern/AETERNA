# Quick Start UI/UX Design Guide

Get up to speed with UI/UX design fundamentals in hours, not months.

## What's Inside
1. **Core Principles** – The 10 rules every designer must know
2. **Color Theory** – Choosing palettes that convert
3. **Typography Guide** – Font pairing and hierarchy
4. **Layout Patterns** – Grid systems and spacing
5. **Figma Cheatsheet** – Essential shortcuts and workflows
6. **User Research Templates** – Interview scripts and survey templates

## Quick Start
Open the guides in order. Each section builds on the previous.

## Tools Referenced
- Figma (free plan works)
- Coolors.co (color palette generator)
- Google Fonts
