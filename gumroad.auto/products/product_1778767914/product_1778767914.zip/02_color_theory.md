# Color Theory for UI/UX Designers

## Color Roles
| Role | Purpose | Example |
|------|---------|---------|
| Primary | Main brand color | #3B82F6 (blue) |
| Secondary | Accent, highlights | #8B5CF6 (purple) |
| Neutral | Text, backgrounds | #1F2937, #F9FAFB |
| Success | Positive states | #10B981 (green) |
| Warning | Caution states | #F59E0B (amber) |
| Error | Failure states | #EF4444 (red) |

## Proven Palette Combinations
1. **Professional**: Navy + White + Gold accent
2. **Modern SaaS**: Gray-900 + Indigo-600 + White
3. **Warm Brand**: Slate + Orange-500 + Off-white
4. **Minimal**: Black + White + 1 color accent

## Contrast Requirements (WCAG AA)
- Normal text: 4.5:1 minimum
- Large text: 3:1 minimum
- Interactive elements: 3:1 minimum

## Pro Tips
- 60% dominant color, 30% secondary, 10% accent
- Never use pure black (#000) — use #111 or #1F2937
- Dark mode: flip neutrals, keep primary 10-15% lighter
