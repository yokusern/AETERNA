# User Research Templates

## User Interview Script

**Before you start**: Record with permission. Listen 80%, talk 20%.

### Opening (5 min)
"Thank you for joining. I'm researching [topic]. There are no right or wrong answers — I want to understand your experience."

### Warm-up Questions
1. Tell me about yourself and what you do.
2. How do you currently handle [problem area]?
3. Walk me through the last time you [relevant task].

### Core Questions
1. What's the most frustrating part of [problem area]?
2. What tools or methods do you currently use? Why?
3. What would make this 10x better for you?
4. How much would you pay for a perfect solution?

### Closing
"Is there anything else you'd like to share?"

---

## Survey Template

**Title**: Help us improve [product name]

1. How did you first hear about us? (Multiple choice)
2. How often do you use [product]? (1-7 days/week)
3. What's your #1 reason for using us?
4. What would make you recommend us to a friend? (Open text)
5. On a scale of 1-10, how likely are you to recommend us? (NPS)
6. What feature would you most like to see added? (Open text)
