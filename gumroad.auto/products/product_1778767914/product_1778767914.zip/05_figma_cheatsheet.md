# Figma Essential Shortcuts

## Navigation
| Shortcut | Action |
|----------|--------|
| Cmd/Ctrl + 0 | Zoom to 100% |
| Cmd/Ctrl + Shift + H | Zoom to fit |
| Space + drag | Pan canvas |
| Cmd/Ctrl + [ or ] | Move layer up/down |

## Selection & Editing
| Shortcut | Action |
|----------|--------|
| V | Select tool |
| F | Frame tool |
| R | Rectangle |
| T | Text |
| Cmd/Ctrl + D | Duplicate |
| Cmd/Ctrl + G | Group |
| Cmd/Ctrl + Shift + G | Ungroup |
| Alt + drag | Copy element |

## Components
| Shortcut | Action |
|----------|--------|
| Cmd/Ctrl + Alt + K | Create component |
| Alt + 2 | Components panel |
| Cmd/Ctrl + / | Search commands |

## Auto Layout
| Shortcut | Action |
|----------|--------|
| Shift + A | Add auto layout |
| Alt + click padding | Edit individual padding |
