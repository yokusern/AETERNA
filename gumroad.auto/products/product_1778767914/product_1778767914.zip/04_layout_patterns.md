# Layout Patterns & Grid Systems

## The 8px Grid
Use multiples of 8 for all spacing: 8, 16, 24, 32, 40, 48, 64, 80, 96...
This creates visual harmony and works across all screen sizes.

## Common Layout Patterns

### Hero Section
```
[Full-width background]
  [Max-width container: 1200px]
    [Heading - center or left]
    [Subheading]
    [CTA Button(s)]
    [Hero image/illustration]
```

### Feature Grid
```
[3 or 4 column grid]
  [Icon] [Icon] [Icon]
  [Title] [Title] [Title]
  [Description] [Description] [Description]
```

### Pricing Table
```
[3 columns: Free | Pro | Enterprise]
  Each column: Name, Price, Features list, CTA
  Highlight recommended plan
```

## Spacing Reference
| Context | Spacing |
|---------|---------|
| Within a component | 8–16px |
| Between related items | 16–24px |
| Between sections | 48–80px |
| Page padding (mobile) | 16–24px |
| Page padding (desktop) | 80–120px |
