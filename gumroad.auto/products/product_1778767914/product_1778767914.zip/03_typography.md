# Typography Guide

## Font Pairing Formula
Heading + Body = Different weights of the same family, OR
Serif heading + Sans-serif body (classic), OR
Display + Clean sans (modern)

## Recommended Free Pairs
| Heading | Body | Style |
|---------|------|-------|
| Inter Bold | Inter Regular | Modern, tech |
| Playfair Display | Lato | Editorial |
| Montserrat | Open Sans | Corporate |
| Space Grotesk | Plus Jakarta Sans | Startup |

## Type Scale (base 16px)
| Name | Size | Use |
|------|------|-----|
| xs | 12px | Labels, captions |
| sm | 14px | Secondary text |
| base | 16px | Body copy |
| lg | 18px | Lead text |
| xl | 20px | Small headings |
| 2xl | 24px | H3 |
| 3xl | 30px | H2 |
| 4xl | 36px | H1 |

## Line Height Rules
- Body text: 1.5–1.7
- Headings: 1.1–1.3
- Buttons/labels: 1.0–1.2
