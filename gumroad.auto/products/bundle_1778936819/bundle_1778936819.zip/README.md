# Complete Prompt Pack Collection

**4 products bundled together — $38 (save $21, 36% off)**

## What's Included

1. **ChatGPT Business Prompt Mega Pack** (normally $17.0)
   Type: prompt pack

2. **100 ChatGPT & Claude Prompts for Content Creators** (normally $15.0)
   Type: prompt pack

3. **Social Media Content Prompt Pack (500 Prompts)** (normally $15.0)
   Type: prompt pack

4. **Midjourney Prompt Pack — 200 Premium Prompts** (normally $12.0)
   Type: prompt pack

## How to Use

Each product is in its own folder inside this ZIP.
Open each folder to find the files — ZIPs, spreadsheets, guides, etc.

For Notion templates: import the CSV files via Notion's Import feature.
For HTML tools: double-click the .html file to open in your browser.
For spreadsheets: open the .xlsx file in Excel or Google Sheets.

*© AETERNA Holdings*