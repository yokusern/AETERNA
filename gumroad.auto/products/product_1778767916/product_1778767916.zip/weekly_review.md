# Weekly Review Template

## Week of: {{week_start}} – {{week_end}}

### 🏆 Wins This Week
1. 
2. 
3. 

### ❌ What Didn't Go Well
1. 
2. 

### 📊 Metrics
| Metric | Goal | Actual |
|--------|------|--------|
| Focused hours | 30h | |
| Tasks completed | 20 | |
| Exercise sessions | 4 | |

### 🔮 Next Week's Focus
1. 
2. 
3. 

### 💡 Key Learnings
_What did you learn this week?_
