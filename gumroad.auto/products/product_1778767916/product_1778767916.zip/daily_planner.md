# Daily Planner Template

## 📅 Date: {{date}}

### 🎯 Top 3 Priorities
- [ ] Priority 1
- [ ] Priority 2
- [ ] Priority 3

### ⏰ Time Blocks
| Time | Task | Status |
|------|------|--------|
| 8:00 AM | Morning routine | ⬜ |
| 9:00 AM | Deep work | ⬜ |
| 12:00 PM | Lunch break | ⬜ |
| 1:00 PM | Meetings | ⬜ |
| 3:00 PM | Admin tasks | ⬜ |
| 5:00 PM | Review & plan tomorrow | ⬜ |

### 📝 Notes
_Your notes here_

### ✅ End of Day Reflection
- What went well?
- What could improve?
- Energy level: ⭐⭐⭐⭐⭐
