# Project Hub Template

## Project: {{project_name}}

**Status**: 🟡 In Progress  
**Owner**: {{your_name}}  
**Due Date**: {{due_date}}  
**Priority**: High / Medium / Low

---

## 🎯 Goal
_What does success look like?_

## 📋 Tasks
### To Do
- [ ] Task 1
- [ ] Task 2

### In Progress
- [ ] Task 3

### Done
- [x] Task 4

## 📌 Resources
- [Link 1](url)
- [Link 2](url)

## 📝 Meeting Notes
| Date | Attendees | Key Points |
|------|-----------|------------|
| | | |
