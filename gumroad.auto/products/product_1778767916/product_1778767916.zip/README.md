# Notion Templates Essentials
A curated collection of Notion templates to supercharge your productivity.

## Included Templates
1. Daily Planner – Plan your day with time blocks and priorities
2. Weekly Review – Reflect and improve each week
3. Project Hub – Manage projects with kanban-style boards
4. Reading List – Track books and key takeaways
5. Goal Tracker – Set quarterly goals and milestones

## How to Use
1. Open Notion and create a new page
2. Copy the template code from the .md files below
3. Customize colors, properties, and views to fit your workflow

## Support
Email: support@aeternaholdings.com
