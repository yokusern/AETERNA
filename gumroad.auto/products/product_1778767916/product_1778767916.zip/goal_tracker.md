# Quarterly Goal Tracker

## Q{{quarter}} {{year}} Goals

### 🏆 Goal 1: {{goal_1_title}}
**Why it matters**: 
**Deadline**: 
**Success metric**: 

#### Milestones
- [ ] Week 4: 
- [ ] Week 8: 
- [ ] Week 12: 

---

### 🏆 Goal 2: {{goal_2_title}}
**Why it matters**: 
**Deadline**: 
**Success metric**: 

#### Milestones
- [ ] Week 4: 
- [ ] Week 8: 
- [ ] Week 12: 

---

### 📊 Progress Tracker
| Week | Goal 1 | Goal 2 | Overall |
|------|--------|--------|---------|
| 1 | 0% | 0% | 0% |
| 4 | | | |
| 8 | | | |
| 12 | | | |
